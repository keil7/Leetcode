class Solution {
public:
    int lengthOfLongestSubstring(string s) {
		if(s.empty())
			return 0;
		char table[128] = {0}; // important to initilize array!
		int maxLen = 0;
		int start = 0;
		int end = 0;
		while(end < s.length()) {
			if(table[s[end]] == 0) {
				table[s[end]] = 1;
				maxLen = max(maxLen,end-start+1);
				end++;
				continue;
			}
			//duplicated char found
			while(s[start] != s[end]) {
				table[s[start]] = 0;
				start++;
			}
			table[s[start]] = 0;
			start++;
		}
		
		return maxLen;
    }
};
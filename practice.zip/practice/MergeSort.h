void MergeSort(int a[], int startIndex, int endIndex) {
    if(startIndex >= endIndex)
        return;
    int mid = (startIndex + endIndex) / 2;
    MergeSort(a,startIndex,mid);
    MergeSort(a,mid+1,endIndex);
    Merge(a,startIndex,mid,endIndex);
}

void Merge(int a[], int startIndex, int mid, int endIndex) {
    int* pArray = new int[endIndex-startIndex+1];
    int index1 = startIndex, index2 = mid + 1;
    for(int i = 0; i < endIndex-startIndex+1; i++) {
        if((index1 <= mid) && (a[index1] < a[index2]))
            pArray[i] = a[index1++];
        else
            pArray[i] = a[index2++];
    }
    for(int i = 0; i <= endIndex-startIndex+1; i++) {
        a[startIndex+i] = pArray[i];
    }
}
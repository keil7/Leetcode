struct ListNode {
	int value;
	ListNode* nextNode;
}

bool bHasRing(ListNode* head, ListNode*& pFast, ListNode*& pSlow) {
	if(!head)
		return false;
	
	pFast = head;
	pSlow = head;
	
	while(1) {
		if(pFast->nextNode != NULL && pFast->nextNode->nextNode != NULL) {
			pFast = pFast->nextNode->nextNode;
		}
		else {
			return fasle;
		}
		pSlow = pSlow->nextNode;
		if(pFast == pSlow)
			return true;
	}
}

ListNode* getEntryOfRing(ListNode* head) {
	ListNode* pRight = NULL;
	ListNode* pLsft = NULL;
	
	if(!bHasRing(head,pRight,pLeft))
		return NULL;
	
	int lengthOfRing = 0;
	while(1) {
		pRight = pRight->nextNode;
		lengthOfRing++;
		if(pRight == pLeft)
			break;
	}
	 pRight = head;
	 pLeft = head;
	 
	 for(int i = 0; i <= lengthOfRing; ++i) {
		 pRight = pRight->nextNode;
	 }
	 
	 while(pRight != pLeft) {
		 pRight = pRight->nextNode;
		 pLeft = pLeft->nextNode;
	 }
	 
	 return pRight;
}
void PostOrder(TreeNode* pRoot) {
    if(pRoot == NULL)
        return;
    TreeNode* curr = NULL,* pPreNode = NULL;
    stack<TreeNode*> stack;
    stack.push(pRoot);
    while(!stack.empty()) {
        curr = stack.top();
        if(!pPreNode || curr == pPreNode->pLeft || curr == pPreNode->pRight) {
            if(curr->pLeft)
                stack.push(curr->pLeft);
            else if(curr->pRight)
                stack.push(curr->pRight);
        }
        else if(curr->pLeft == pPreNode) {
            if(curr->pRight)
                stack.push(curr->pRight);
        }
        else {
            cout<< curr->nValue<<endl;
            stack.pop();
        }
        pPreNode = curr;
    }
}

void inOrder(TreeNode* pRoot) {
    TreeNode* curr = pRoot;
    stack<TreeNode *> stack;
    while(curr || !stack.empty()) {
        if(curr) {
            stack.push(curr);
            curr = curr->pLeft;
        }
        else {
            curr = stack.top();
            stack.pop();
            cout<<curr->nValue<<endl;
            curr = curr->pRight;
        }
    }
}
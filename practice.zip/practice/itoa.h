class Solution {
public:
    int myAtoi(string str) {
        int retNum = 0;
		int len = str.length();
		int sign = 1;
        // also include 0 length string case
		size_t pos = str.find_first_not_of(' ');
		if(pos == string::npos)
			return retNum;
		//first non blank char is number
		if((str[pos] >= '0') && (str[pos] - '0' <= 9))
			retNum = str[pos++] - '0';
		else if((str[pos] == '+' || str[pos] == '-')) {
			if(str[pos] == '-')
				sign = -1;
			pos++;
			while((pos < len) && (str[pos] >= '0') && (str[pos] - '0' <= 9)) {
				if(str[pos] != '0') {
					retNum = (str[pos] - '0') * sign;
					pos++;
					break;
				}
				pos++;
			}
		}
		//invalid cases
		else
			return retNum;
		
		while((pos < len) && (str[pos] >= '0') && (str[pos] - '0' <= 9)) {
			int digit = str[pos] - '0';
			//postive number
			if(retNum >= 0) {
				// no overflow
				if(((INT_MAX - digit) / 10) >= retNum)
					retNum = retNum * 10 + digit;
				else {
					retNum = INT_MAX;
					break;
				}
			}
			//negative number
			else {
				if(((INT_MIN + digit) / 10) <= retNum)
					retNum = retNum * 10 - digit;
				else {
					retNum = INT_MIN;
					break;
				}
			}
			pos++;
		}
		return retNum;
    }
};
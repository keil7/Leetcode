class Solution {
public:
    bool isPalindrome(int x) {
        if(x < 0)
			return false;
		int num = x;
		int ix = 0;
		while(num) {
			int digit = num % 10;
			num /= 10;
			if(ix < (INT_MAX - digit) / 10) {
				ix = ix * 10 + digit;
			}
			else {
				return false;
			}
		}
		while(x != 0 && ix != 0) {
			int digit1 = x % 10;
			int digit2 = ix % 10;
			if(digit1 != digit2)
				return false;
			x /= 10;
			ix /= 10;
		}
		return true;
    }
};
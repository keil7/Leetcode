ListNode* DeleteRepeatNode(ListNode* head) {
	if(head == NULL)
		return NULL;
	ListNode* currentNode = head;
	while(currentNode->nextNode) {
		if(currentNode->nextNode->value == currentNode->value) {
			ListNode* temp = currentNode->nextNode;
			currentNode->nextNode = temp->nextNode;
			delete temp;
		}
		currentNode = currentNode->nextNode;
	}
	return head;
}
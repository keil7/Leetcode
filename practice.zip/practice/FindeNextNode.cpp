BinaryNode* FindNextNode (BinaryNode* pRoot,BinaryNode* pNode) {
	if(!pRoot || !pNode)
		return NULL;
		
	if(pNode->pRight) {
		BinarNode* pNext = pNode->pRight;
		while(pNext->pLeft) {
			pNext = pNext->pLeft;
		}
		return pNext;
	}
	
	//root of left sub-tree
	BinaryNode* pCurrentNode = pNode;
	while(pCurrentNode->pParent) {
		if(pCurrentNode == pCurrentNode->pParent->pLeft)
			return pCurrentNode;
		pCurrentNode = pCurrentNode->pParent;
	}
	
	return NULL;
	
}
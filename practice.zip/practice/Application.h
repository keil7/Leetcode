#ifndef APPLICATION_H
#define APPLICATION_H 

Class Application {
public:
    Application() {
    }
    ~Application();
    bool getInputFreezingThreshold();
    bool getInputBoilingThreshold();
    bool getInputFluctuationValue();
    bool getInputTemperature();
    void getOutput();
private:
    float freezingThreshold;
    float boilingThreshold;
    float fluctuationValue;
    float* pInputTemperature;
};

#endif
class Solution {
public:
    string longestPalindrome(string s) {
        if(s.length() <= 1)
			return s;
		int maxLen = 0;
		int startIndex = 0;
		for(int i = 0; i < s.length(); ++i) {
			int len1 = 2 * calculatePairNum(s,i-1,i+1) + 1;
			int len2 = 2 * calculatePairNum(s,i-1,i);
			if(len1 > len2) {
				if(len1 > maxLen) {
					maxLen = len1;
					startIndex = i - (len1 - 1) / 2;
				}
			}
			else {
				if(len2 > maxLen) {
					maxLen = len2;
					startIndex = i - len2 / 2;
				}
			}
		}
		return s.substr(startIndex,maxLen);
    }
	
private:
	int calculatePairNum(string s, int left, int right) {
		int pairNum = 0;
		while(left >= 0 && right < s.length() && s[left] == s[right]) {
			pairNum++;
			left--;
			right++;
		}
		return pairNum;
	}
};

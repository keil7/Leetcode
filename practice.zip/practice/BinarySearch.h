// Example program
#include <iostream>
#include <string>

class Solution {
public:
    int BinarySearchRecursive(int a[], int val, int low, int high) {
        if(low < 0 || high < 0 || low > high)
            return -1;
        int mid = (low + high + 1) / 2;
        if(a[mid] == val)
            return mid;
        else if(a[mid] > val)
            return BinarySearchRecursive(a,val,low,mid-1);
        else
            return BinarySearchRecursive(a,val,mid+1,high);
    }
    int BinarySearch(int a[], int val, int size) {
        if(size <= 0)
            return -1;
        int low = 0;
        int high = size-1;
        while(low <= high) {
            int mid = (low + high +1) / 2；
            if(val == a[mid])
                return mid;
            else if(val < a[mid])
                high = mid - 1;
            else
                low = mid + 1;    
        }
        
        return -1;
    }
};
int main()
{
  int a[] = {0,2,3,6,8,9};
  int b[] = {2};
  Solution s;
  std::cout<< s.BinarySearchRecursive(b,1,0,sizeof(b)/sizeof(int)-1) <<std::endl;
}
Class Singleton {
    public:
        static Singleton& Instance() {
            static Singleton instance;
            return instance;
        }
        
    private:
        Singleton();
        Singleton(Singleton&);
        Singleton& operator=(Singleton&);
        ~Singleton();
}
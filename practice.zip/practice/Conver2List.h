void construct(BSTNode* pRoot, BSTNode* pLastNode) {
	if(!pRoot)
		return;
	construct(pRoot->pLeft,pLastNode);
	if(pLastNode) {
		pRoot->pLeft = pLastNode;
		pLastNode->pRight = pRoot; 
	}
	pLastNode = pRoot;
	construct(pRoot->pRight,pLastNode);
}
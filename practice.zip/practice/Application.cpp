#include "Application.h"
#include <iostream>

Application::Application(): freezingThreshold(0.0), boilingThreshold(100.0),
                            fluctuationValue (0.0), pInputTemperature(nullptr) {
}

Application::~Application() {
    delete []pInputTemperature;
    pInputTemperature = nullptr;
}

bool Application::getInputFreezingThreshold() {
    std::cout<<"Please input Freezing Threshold.\n";
    while(!getInputValue(freezingThreshold)) {
        std::cout<<"Your Input is invalid, please re-input.\n";
    }
    std::cout<<"Set Freezing Threshold to" + freezingThreshold + ".\n";
}

bool Application::getInputBoilingThreshold() {
    std::cout<<"Please input Boiling Threshold.\n";
    while(!getInputValue(boilingThreshold)) {
        std::cout<<"Your Input is invalid, please re-input.\n";
    }
    std::cout<<"Set Boiling Threshold to" + boilingThreshold + ".\n";
}

bool Application::getInputFluctuationValue() {
    std::cout<<"Please input Fluctuation Value (positive number).\n";
    while(!getInputValue(fluctuationValue) || fluctuationValue < 0) {
        std::cout<<"Your Input is invalid, please re-input.\n";
    }
    std::cout<<"Set Fluctuation Value to" + fluctuationValue + ".\n";
}

bool Application::getInputValue(float& value) {
    std::string str;
    std::cin >> str;
    
}
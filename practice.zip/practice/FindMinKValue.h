// Example program
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

bool Greater(int a, int b) {
    return a > b;
}

std::vector<int> FindMinKValue(std::vector<int>& value, const int k) {
    if(value.size() < k)
        return std::vector<int>();
    
    std::vector<int> res;
    std::make_heap(value.begin(),value.end(),Greater);
    
    for(int i = 1; i <= k; ++i) {
        res.push_back(value.front());
        std::cout<<"Insert "<<value.front()<<std::endl;
        std::pop_heap(value.begin(),value.end(),Greater);
        std::cout<<"Remove "<<value.back()<<std::endl;
        value.pop_back();
    }
    return res;
}


int main()
{
  int arr[] = {2,3,5,6,8,1,4,7,10};
  std::vector<int> value(arr,arr+sizeof(arr)/sizeof(int));
  std::vector<int> res = FindMinKValue(value,4);
  for(auto i : res) {
      std::cout<<i<<" ";
  }
  std::cout<<std::endl;
  for(auto i : value) {
      std::cout<<i<<" ";
  }
  std::cout<<std::endl;
}

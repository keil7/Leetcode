// Example program
#include <iostream>
#include <string>

class Solution {
public:
    void QuickSort(int a[], int left, int right) {
        if(left < right) {
            int index = partition(a,left,right);
            QuickSort(a,left,index-1);
            QuickSort(a,index+1,right);
        }
    }
private:
    int partition(int a[], int left, int right) {
        int i = left - 1;
        for(int j = left; j < right; ++j) {
            if(a[j] < a[right]) {
                i++;
                std::swap(a[i],a[j]);
            }
        }
        std::swap(a[i+1],a[right]);
        return i+1;
    }
    
};
int main()
{
  int a[] = {0,2,6,2,1,3,-1};
  int size = sizeof(a)/sizeof(int);
  Solution s;
  s.QuickSort(a,0,size-1);
  for(auto i : a) 
    std::cout<<i<<" ";
}
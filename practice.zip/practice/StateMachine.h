
/// StateIdle
const VDVoiceClientHandler::State VDVoiceClientHandler::StateIdle =                                                \
{                                                                                                              \
    g_pTransState_StateIdle,                                                                                 \
    NULL,                                                                                               \
    NULL,                                                                                           \
    NULL,                                                                                                 \
    NULL,                                                                                               \
    NULL,                                                                                                \
    ("StateIdle"),                                                                                              \
    ("NULL"),                                                                                            \
    ("NULL")                                                                                              \
};                                                                                                             \
                                                                                                               \
const VDVoiceClientHandler::Transition VDVoiceClientHandler::g_pTransState_StateIdle[] =                         \
{
	{EVENT_Play, &VDVoiceClientHandler::ActionApplyAudioSource, &StateApplyingAudioSource, ("&StateMachine_Class::ActionApplyAudioSource")},
	{EVENT_Abort, &VDVoiceClientHandler::ActionSendStopFinish, NULL, ("&StateMachine_Class::ActionSendStopFinish")},
	{EVENT_Invalid, NULL, NULL, NULL}                                                                                \
};

/// StateApplyingAudioSource
const VDVoiceClientHandler::State VDVoiceClientHandler::StateApplyingAudioSource =                                                \
{                                                                                                              \
    g_pTransState_StateApplyingAudioSource,                                                                                 \
    NULL,                                                                                               \
    NULL,                                                                                           \
    NULL,                                                                                                 \
    NULL,                                                                                               \
    NULL,                                                                                                \
    ("StateApplyingAudioSource"),                                                                                              \
    ("NULL"),                                                                                            \
    ("NULL")                                                                                              \
};                                                                                                             \
                                                                                                               \
const VDVoiceClientHandler::Transition VDVoiceClientHandler::g_pTransState_StateApplyingAudioSource[] =                         \
{
	{EVENT_AudioSourceOn, &VDVoiceClientHandler::ActionPlay, &StatePlayerPlaying, ("&StateMachine_Class::ActionPlay")},
	{EVENT_Error, &VDVoiceClientHandler::ActionSendPlayError, &StateIdle, ("&StateMachine_Class::ActionSendPlayError")},
	{EVENT_AudioSourceTimeOut, &VDVoiceClientHandler::ActionSendPlayError, &StateIdle, ("&StateMachine_Class::ActionSendPlayError")},
	{EVENT_Play, NULL, NULL, ("NULL")},
	{EVENT_Abort, &VDVoiceClientHandler::ActionSetStopFinishAndReleaseAudioSource, &StateReleasingAudioSource, ("&StateMachine_Class::ActionSetStopFinishAndReleaseAudioSource")},
	{EVENT_Invalid, NULL, NULL, NULL}                                                                                \
};

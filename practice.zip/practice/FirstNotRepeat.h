char FirstNotRepeat(std::string str) {
	if(str.empty())
		return '#'
	
	int table[256] = {-1};
	for(int i =0; i < str.length();++i) {
		if(table[str[i]] == -1)
			table[str[i]] = i;
		else
			table[str[i]] = -2;
	}
	
	int min = str.length();
	for(int i =0; i < str.length();++i) {
		if(table[i]) >= 0)
			min = std::min(min,table[i]);
	}
	
	return min == str.length() ? '#' : min;
}